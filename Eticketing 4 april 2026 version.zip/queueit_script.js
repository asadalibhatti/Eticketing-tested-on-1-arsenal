// queueit_script.js

console.log("[QueueIt Script] Script loaded on:", window.location.href);

/** When queue UI shows people ahead / progress, wait longer before treating reCAPTCHA as stuck or redirecting without iframe. */
const RECAPTCHA_SOLVE_TIMEOUT_MS = 30000;
const RECAPTCHA_SOLVE_TIMEOUT_PEOPLE_AHEAD_MS = 180000; // ~3 minutes
const NO_RECAPTCHA_IFRAME_REDIRECT_SEC = 50;
const NO_RECAPTCHA_IFRAME_REDIRECT_PEOPLE_AHEAD_SEC = 180; // ~3 minutes

/** Returns true if the page shows \"people ahead of you\", the main queue progress bar, or the \"Your queue position will be updated in:\" warning box (user is in queue and must wait). */
function hasPeopleAheadOfYouVisible() {
    // Check for "people ahead of you" text
    const peopleAheadEl = document.querySelector('#MainPart_lbUsersInLineAheadOfYouText');
    if (peopleAheadEl) {
        const text = (peopleAheadEl.textContent || '').trim();
        if (text.indexOf('people ahead of you') !== -1) {
            const style = window.getComputedStyle(peopleAheadEl);
            if (style.display !== 'none' && style.visibility !== 'hidden' && peopleAheadEl.offsetParent !== null) {
                return true;
            }
        }
    }
    
    // Check for progress bar (queue position update indicator)
    const progressBar = document.querySelector('#MainPart_divProgressbar');
    if (progressBar) {
        const style = window.getComputedStyle(progressBar);
        if (style.display !== 'none' && style.visibility !== 'hidden' && progressBar.offsetParent !== null) {
            return true;
        }
    }

    // Check for \"Your queue position will be updated in:\" warning box (same waiting state)
    const warningBoxTextEl = document.querySelector('.warning-box p.extrabeforeElement');
    if (warningBoxTextEl) {
        const text = (warningBoxTextEl.textContent || '').trim().toLowerCase();
        if (text.indexOf('your queue position will be updated in') !== -1) {
            const style = window.getComputedStyle(warningBoxTextEl);
            if (style.display !== 'none' && style.visibility !== 'hidden' && warningBoxTextEl.offsetParent !== null) {
                return true;
            }
        }
    }
    
    return false;
}

/**
 * True only when #buttonConfirmVisitorPresence shows the clickable "Yes, I'm here" label (not the hidden KO template).
 * Button `textContent` still includes "I'm here" from a `display:none` span — must check visibility.
 */
function isVisitorPresenceImHerePromptVisible(button) {
    if (!button) return false;
    const spans = button.querySelectorAll('span.l');
    for (let i = 0; i < spans.length; i++) {
        const sp = spans[i];
        const raw = (sp.textContent || '').replace(/\s+/g, ' ').trim();
        if (raw.indexOf("I'm here") === -1) continue;
        const st = window.getComputedStyle(sp);
        if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') continue;
        const r = sp.getBoundingClientRect();
        if (r.width <= 0 || r.height <= 0) continue;
        return true;
    }
    return false;
}

function isVisitorPresenceButtonClickable(button) {
    if (!button) return false;
    if (button.disabled) return false;
    if (button.hasAttribute('disabled')) return false;
    if (button.getAttribute('aria-disabled') === 'true') return false;
    return true;
}

/** Send setQueueWaiting message to background every 3s so background knows we're still in queue; background clears flag if no message in 10s. */
function sendQueueWaitingToBackground() {
    const onQueueUrl = window.location.href.startsWith('https://hd-queue.eticketing.co.uk') ||
        window.location.href.startsWith('http://hd-queue.eticketing.co.uk');
    const waiting = onQueueUrl && hasPeopleAheadOfYouVisible();
    if (waiting) queueFlagEverSeen = true;
    chrome.runtime.sendMessage({ action: 'setQueueWaiting', inQueueWaiting: waiting }, () => {
        if (chrome.runtime.lastError) return;
        if (waiting) console.log("[QueueIt Script] In queue (people ahead or progress bar visible) - sent setQueueWaiting true");
    });
}

let queueFlagEverSeen = false; // true if "people ahead" or progress bar has been visible at any time on this page
let joinWaitingRoomButtonClicked = false; // track if "Join waiting room" button was clicked
let confirmRedirectButtonClicked = false; // track if "Yes, please" confirm redirect button was clicked
let getNewPlaceInQueueClicked = false; // track if "Get a new place in the queue" link was clicked
let confirmVisitorPresenceClicked = false; // "Yes, I'm here" (#buttonConfirmVisitorPresence)
let captchaCodeLabelHandled = false; // track if "Enter the code from the picture" label was handled
let browsingPausedUntil = 0; // when \"Your browsing activity has been paused\" was seen; back off actions for 60s

if (window.location.href.startsWith("https://hd-queue.eticketing.co.uk") || window.location.href.startsWith("http://hd-queue.eticketing.co.uk")) {
    // If we're on the error403 page, notify background and do not run any queue logic (pause until background resumes after wait)
    if (window.location.href.indexOf('error403') !== -1) {
        console.log("[QueueIt Script] error403 page detected - pausing script and notifying background.");
        chrome.runtime.sendMessage({ action: 'error403Detected' }, () => {
            if (chrome.runtime.lastError) console.error('[QueueIt Script] error403Detected error:', chrome.runtime.lastError);
        });
        // Do not start queue checks, 120s timeout, or sendQueueWaiting
        // Background will wait (5/7/9... min) then reopen/reload tabs same as sheet on/off
    } else {
        console.log("[QueueIt Script] Running on the correct page.");

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', startQueueItScript);
        } else {
            startQueueItScript();
        }

        // Send setQueueWaiting to background every 3s; background clears flag if no message in 10s
        setInterval(sendQueueWaitingToBackground, 3000);
        sendQueueWaitingToBackground(); // run once on load

        // If neither "people ahead" nor progress bar appears after 120s, clear cookies and reopen event URL in same tab (do not clear if flag was ever seen)
        setTimeout(() => {
            if (queueFlagEverSeen) return;
            if (hasPeopleAheadOfYouVisible()) return;
            console.log("[QueueIt Script] No queue indicators after 120s - clearing cookies and reopening event URL in same tab");
            chrome.runtime.sendMessage({ action: 'clearCookiesAndReopenInSameTab' }, () => {
                if (chrome.runtime.lastError) console.error('[QueueIt Script] clearCookiesAndReopenInSameTab error:', chrome.runtime.lastError);
            });
        }, 120000);
    }

    function startQueueItScript() {
        console.log("[QueueIt Script] Starting queue-it script...");

        let checkCount = 0;
        const maxChecks = 200; // slight increase since we wait up to 28s
        let recaptchaTimeout;
        const startTime = Date.now();
        let iframeFound = false;
        let cookiesCleared = false;

        const checkElements = setInterval(async () => {
            checkCount++;
            const elapsed = (Date.now() - startTime) / 1000;

            if (checkCount > maxChecks) {
                console.log("[QueueIt Script] Stopping checks after max attempts");
                clearInterval(checkElements);
                return;
            }

            // If Chrome/page shows "Your browsing activity has been paused", back off for 60s before taking any queue actions
            try {
                const bodyText = (document.body && document.body.innerText) || '';
                if (bodyText.toLowerCase().includes('your browsing activity has been paused')) {
                    const now = Date.now();
                    if (now >= browsingPausedUntil) {
                        browsingPausedUntil = now + 60000; // 60 seconds
                        console.log("[QueueIt Script] 'Your browsing activity has been paused' detected - backing off actions for 60 seconds");
                    }
                }
            } catch (_) {}
            if (Date.now() < browsingPausedUntil) {
                return; // skip this iteration; do nothing while paused
            }

            // --- Click "Join waiting room" button as soon as it appears ---
            const joinWaitingRoomButton = document.querySelector('button.botdetect-button.btn');
            if (joinWaitingRoomButton && !joinWaitingRoomButtonClicked) {
                const buttonText = (joinWaitingRoomButton.textContent || '').trim();
                if (buttonText === 'Join waiting room') {
                    joinWaitingRoomButtonClicked = true;
                    console.log("[QueueIt Script] 'Join waiting room' button found, clicking immediately...");
                    joinWaitingRoomButton.click();
                }
            }

            // --- Click "Yes, please" confirm redirect button as soon as it appears ---
            const confirmRedirectButton = document.querySelector('button#buttonConfirmRedirect');
            if (confirmRedirectButton && !confirmRedirectButtonClicked) {
                const text = (confirmRedirectButton.textContent || '').trim();
                if (text.indexOf('Yes, please') !== -1) {
                    confirmRedirectButtonClicked = true;
                    console.log("[QueueIt Script] 'Yes, please' confirm redirect button found, clicking immediately...");
                    confirmRedirectButton.click();
                }
            }

            // --- Click "Yes, I'm here" visitor-presence button only when that label is visible (not hidden KO span) ---
            const visitorPresenceBtn = document.querySelector('button#buttonConfirmVisitorPresence');
            if (
                visitorPresenceBtn &&
                !confirmVisitorPresenceClicked &&
                isVisitorPresenceButtonClickable(visitorPresenceBtn) &&
                isVisitorPresenceImHerePromptVisible(visitorPresenceBtn)
            ) {
                confirmVisitorPresenceClicked = true;
                console.log("[QueueIt Script] 'Yes, I'm here' (#buttonConfirmVisitorPresence) visible and clickable — clicking...");
                visitorPresenceBtn.click();
            }

            // --- Click "Get a new place in the queue" link as soon as it appears ---
            if (!getNewPlaceInQueueClicked) {
                const getNewPlaceLink = Array.from(document.querySelectorAll('a.btn')).find(a => {
                    const t = (a.textContent || '').trim();
                    return t.indexOf('Get a new place in the queue') !== -1;
                });
                if (getNewPlaceLink) {
                    getNewPlaceInQueueClicked = true;
                    console.log("[QueueIt Script] 'Get a new place in the queue' link found, clicking immediately...");
                    getNewPlaceLink.click();
                }
            }

            // --- "Enter the code from the picture" label: wait 4s, refresh event tab, close this tab ---
            if (!captchaCodeLabelHandled) {
                const captchaCodeLabel = document.querySelector('label#captcha-code-label[for="CaptchaCode"]');
                const hasLabelText = captchaCodeLabel && (captchaCodeLabel.textContent || '').trim().indexOf('Enter the code from the picture') !== -1;
                if (hasLabelText) {
                    captchaCodeLabelHandled = true;
                    clearInterval(checkElements);
                    console.log("[QueueIt Script] 'Enter the code from the picture' label found - waiting 4s then refreshing event tab and closing this tab.");
                    setTimeout(() => {
                        chrome.runtime.sendMessage({ action: 'refreshEventTabAndCloseQueueTab' }, response => {
                            if (chrome.runtime.lastError) console.error('[QueueIt Script] refreshEventTabAndCloseQueueTab error:', chrome.runtime.lastError);
                        });
                    }, 4000);
                }
            }

            const captchaInput = document.querySelector('input#solution');
            const robotButton = document.querySelector('button.botdetect-button');
            const recaptchaIframe = document.querySelector('iframe[title="recaptcha challenge expires in two minutes"]');

            // --- Detect reCAPTCHA iframe ---
            if (recaptchaIframe) {
                if (!iframeFound) console.log("[QueueIt Script] reCAPTCHA challenge detected, waiting for auto-solve...");
                iframeFound = true;

                if (recaptchaTimeout) clearTimeout(recaptchaTimeout);
                const recaptchaMs = hasPeopleAheadOfYouVisible()
                    ? RECAPTCHA_SOLVE_TIMEOUT_PEOPLE_AHEAD_MS
                    : RECAPTCHA_SOLVE_TIMEOUT_MS;
                recaptchaTimeout = setTimeout(async () => {
                    if (hasPeopleAheadOfYouVisible()) {
                        console.log("[QueueIt Script] reCAPTCHA timeout reached but people ahead / queue UI visible — skipping event tab refresh.");
                        return;
                    }
                    console.log("[QueueIt Script] reCAPTCHA not solved in time. Refreshing event tab...");
                    clearInterval(checkElements);

                    chrome.runtime.sendMessage({action: 'refreshEventTab'}, response => {
                        if (chrome.runtime.lastError) {
                            console.error('[CS] refreshEventTab error:', chrome.runtime.lastError);
                        } else {
                            console.log('[CS] refreshEventTab response:', response);
                        }
                    });
                }, recaptchaMs);
            }

            // --- If iframe not found within N seconds, redirect to event URL (longer wait while people-ahead queue UI is visible) ---
            if (!iframeFound && !cookiesCleared) {
                const needSec = hasPeopleAheadOfYouVisible()
                    ? NO_RECAPTCHA_IFRAME_REDIRECT_PEOPLE_AHEAD_SEC
                    : NO_RECAPTCHA_IFRAME_REDIRECT_SEC;
                if (elapsed >= needSec) {
                    if (hasPeopleAheadOfYouVisible()) {
                        // Do not redirect away from queue while user is clearly in line
                        return;
                    }
                    cookiesCleared = true;
                    console.log("[QueueIt Script] No reCAPTCHA iframe after " + Math.round(needSec) + "s. Redirecting to event URL...");
                    clearInterval(checkElements);
                    const { eventUrl } = await chrome.storage.local.get("eventUrl");
                    if (eventUrl) window.location.href = eventUrl;
                    return;
                }
            }

            // --- Handle captcha input ---
            if (captchaInput && robotButton) {
                console.log("[QueueIt Script] Captcha input and button found.");
                clearInterval(checkElements);

                captchaInput.addEventListener('input', () => {
                    if (captchaInput.value.trim() !== "") {
                        console.log("[QueueIt Script] Captcha input filled. Clicking the button...");
                        robotButton.click();
                    }
                });
            }
        }, 1000);
    }
} else {
    console.log("[QueueIt Script] Not running - URL doesn't match queue pattern");
}
