console.log('TICKET Checking content script loaded on', location.href);

// When event page loads (e.g. after queue or error403 resume), reset queue error403 count so next time wait starts at 5 min
(async () => {
    const { eventUrl } = await chrome.storage.local.get('eventUrl');
    const current = (location.href || '').split('?')[0];
    const storedBase = eventUrl ? eventUrl.split('?')[0] : '';
    if (storedBase && (current === storedBase || current.startsWith(storedBase + '/'))) {
        chrome.runtime.sendMessage({ action: 'resetError403Count' }, () => {
            if (!chrome.runtime.lastError) console.log('[CS] Event URL loaded - reset queue error403Count to 0');
        });
    }
})();

if (document.title.includes("Your Browsing Activity Has")) {
    console.log("[CS] Waiting for tab title to change...");
    let checkTitleInterval = setInterval(() => {
        if (!document.title.includes("Your Browsing Activity has")) {
            clearInterval(checkTitleInterval);
            console.log("[CS] Tab title changed. Proceeding with verification token extraction.");
        } else {
            console.log("[CS] Still waiting for tab title to change...");
        }
    }, 1000);

    setTimeout(() => {
        if (document.title.includes("Your Browsing Activity has")) {
            console.warn("[CS] Tab title did not change within 10 seconds. Reloading the page...");
            window.location.reload();
        }
    }, 60000);
}

let monitor = {
    running: false,
    sheetUrl: null,
    startSecond: null,
    areSeatsTogether: false,
    quantity: null,
    /** When non-null (0–100), each checkOnce rolls pair vs single; updated when sheet row is read. */
    pairCheckChancePct: null,
    discordWebhook: null,
    /** Bot token from sheet column TelegramBotToken (stored under this key for compatibility). */
    telegramWebhook: null,
    telegramChatId: null,
    eventUrl: null,
    eventId: null,
    intervalId: null,
    last403Time: 0
};

/**
 * True if this tab should leave the PublishLogout URL for the stored event URL (same club in storage is not enough — tab can still be on /club/?PublishLogout…).
 */
function shouldNavigateFromPublishLogout(currentHref, storedEventUrl) {
    const st = (storedEventUrl || '').trim();
    if (!st) return false;
    try {
        const cur = new URL(currentHref);
        const tgt = new URL(st.split('#')[0]);
        if (cur.hostname.toLowerCase() !== tgt.hostname.toLowerCase()) return true;
        const normPath = (p) => (p.replace(/\/+$/, '') || '/').toLowerCase();
        if (normPath(cur.pathname) !== normPath(tgt.pathname)) return true;
        const pub = (cur.searchParams.get('PublishLogoutDataLayer') || '').toLowerCase();
        if (pub === 'true') return true;
        return false;
    } catch {
        return true;
    }
}

/**
 * Logout landing: `https://www.eticketing.co.uk/{club}/?PublishLogoutDataLayer=true`
 * If storage already has this club’s eventUrl but this tab is still on the logout URL, navigate to the event URL.
 * Otherwise set eventUrl and ask background to refresh the event tab.
 */
(async function syncEventUrlFromPublishLogoutLanding() {
    try {
        const u = new URL(location.href);
        if (u.hostname.toLowerCase() !== 'www.eticketing.co.uk') return;
        const flag = (u.searchParams.get('PublishLogoutDataLayer') || '').toLowerCase();
        if (flag !== 'true') return;

        const segments = u.pathname.split('/').filter(Boolean);
        if (!segments.length) return;
        const club = segments[0];
        if (!club || !/^[a-z0-9_-]+$/i.test(club)) return;

        const clubOrigin = `https://www.eticketing.co.uk/${club}`;
        const clubPrefixLower = `${clubOrigin.toLowerCase()}/`;

        const storage = await chrome.storage.local.get(['eventUrl', 'eventId']);
        const existing = (storage.eventUrl || '').trim();

        if (existing && existing.toLowerCase().startsWith(clubPrefixLower)) {
            if (shouldNavigateFromPublishLogout(location.href, existing)) {
                const dest = existing.split('#')[0].trim();
                console.log('[CS] PublishLogout landing: redirecting this tab to stored eventUrl:', dest);
                window.location.replace(dest);
                return;
            }
            console.log('[CS] PublishLogout landing: already on stored event path; nudging refreshEventTab —', existing);
            chrome.runtime.sendMessage({ action: 'refreshEventTab' }, () => {
                if (chrome.runtime.lastError) {
                    console.warn('[CS] PublishLogout: refreshEventTab message failed:', chrome.runtime.lastError.message);
                }
            });
            return;
        }

        const eidRaw = storage.eventId != null ? String(storage.eventId).trim() : '';
        const newUrl = eidRaw
            ? `${clubOrigin}/EDP/Event/Index/${eidRaw}`
            : `${clubOrigin}/`;

        await chrome.storage.local.set({ eventUrl: newUrl });
        monitor.eventUrl = newUrl;
        if (eidRaw) monitor.eventId = eidRaw;

        console.log('[CS] PublishLogout landing: set eventUrl for quick event tab:', newUrl);

        chrome.runtime.sendMessage({ action: 'refreshEventTab' }, () => {
            if (chrome.runtime.lastError) {
                console.warn('[CS] PublishLogout: refreshEventTab message failed:', chrome.runtime.lastError.message);
            }
        });
    } catch (e) {
        console.warn('[CS] syncEventUrlFromPublishLogoutLanding error', e);
    }
})();

/** Default % chance to use Resale endpoint when sheet column "Resale Endpoint Chances" is missing or unset. */
const DEFAULT_RESALE_ENDPOINT_CHANCES = 96;

// Club-based PriceClassId mapping
const clubPriceClassIdMap = {
    'arsenal': 1,
    'nottinghamforest': 209,//317 was working before but for champion leage 209
    'cpfc': 1,  // Crystal Palace - default to 1, update if needed
    'chelseafc': 2,  // Chelsea - default to 1, update if needed
    'tottenhamhotspur': 1,
    // Add more clubs as needed
};

// Helper function to get PriceClassId for a club
function getPriceClassIdForClub(clubName) {
    const normalizedClubName = (clubName || '').toLowerCase().trim();
    const priceClassId = clubPriceClassIdMap[normalizedClubName];
    
    if (priceClassId !== undefined) {
        return priceClassId;
    }
    
    // Default fallback to 1 if club not found in map
    console.warn(`[CS] PriceClassId not found for club "${clubName}", using default: 1`);
    return 1;
}
// Auto start monitoring if on the expected page
(async () => {
    if (!window.location.search.includes("eventId=4&reason=EventArchived")) {
        console.warn('[CS] Not on eventId=4&reason=EventArchived page, stopping auto-start');
        return;
    }

    try {
        console.log('[CS] Auto-starting monitor on page load');
        await startMonitorFlow();
    } catch (e) {
        console.error('[CS] Auto startMonitorFlow error:', e);
    }
})();
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'error403Resume') {
        console.log('[CS] error403 pause ended - resuming seat check instantly');
        if (monitor.running) runCheck();
        return;
    }
    if (window.location.search.includes("eventId=4&reason=EventArchived")) {
        if (msg.action === 'startMonitoring') {//start will be from backgroun script
            console.log('[CS] received startMonitoring', msg);
            monitor.sheetUrl = msg.sheetUrl || monitor.sheetUrl;
            monitor.startSecond = (msg.startSecond); // set in extension popup, received as a message

            // eventUrl may be provided in msg or we can get from sheet
            startMonitorFlow().catch(e => console.error('[CS] startMonitorFlow error', e));
        }
        if (msg.action === 'stopMonitoring') {
            stopMonitoring('stop message from background');
        }
    } else {
        // Stop script execution
        console.warn('[CS] not on eventId=4&reason=EventArchived page, stopping script execution');
    }

    return true;
});

async function startMonitorFlow() {
    console.log('[CS] startMonitorFlow begin');

    // currentStatus: currentStatus,
    //                         eventUrl: row.eventUrl,
    //                         startSecond: row.startSecond,
    //                         areSeatsTogether: row.areSeatsTogether === 'true', // convert to boolean
    //                         quantity: parseInt(row.quantity, 10) || 1,
    //                         discordWebhook: row.discordWebhook,
    //                         telegramWebhook: row.telegramWebhook,
    //                         telegramChatId: row.telegramChatId,
    //                         eventId: row.eventId,
    //                         maximumPrice: row.maximumPrice,
    //                         minimumPrice: row.minimumPrice


    const {sheetUrl, startSecond} = await chrome.storage.local.get(['sheetUrl', 'startSecond']);
    monitor.sheetUrl = sheetUrl;
    monitor.startSecond = startSecond;
    const { eventUrl, discordWebhook, telegramWebhook, telegramChatId } = await chrome.storage.local.get([
        'eventUrl', 'discordWebhook', 'telegramWebhook', 'telegramChatId'
    ]);
    monitor.eventUrl = eventUrl;
    if (discordWebhook) monitor.discordWebhook = discordWebhook;
    if (telegramWebhook) monitor.telegramWebhook = telegramWebhook;
    if (telegramChatId != null && String(telegramChatId).trim() !== '') monitor.telegramChatId = String(telegramChatId).trim();
    monitor.areSeatsTogether = await chrome.storage.local.get('areSeatsTogether').then(res => res.areSeatsTogether === true);
    monitor.quantity = await chrome.storage.local.get('quantity').then(res => parseInt(res.quantity || '1', 10));
    monitor.eventId = await chrome.storage.local.get('eventId').then(res => res.eventId || null);


    console.log('[CS] monitor config:', monitor);

    if (!monitor.eventUrl) {
        //read all data from google sheet and set
        console.warn('[CS] no eventUrl found in storage, will not monitor');
        if (monitor.sheetUrl) {
            console.warn('[CS] using sheetUrl', monitor.sheetUrl, 'to read eventUrl');
            //read from sheet
            const row = await getMatchingRowFromSheet(monitor.sheetUrl, monitor.startSecond);
            if (row) {
                const ev = eventUrlFromSheetRow(row);
                if (ev) monitor.eventUrl = ev;
                monitor.startSecond = parseFloat(row.StartSecond) ?? monitor.startSecond;
                syncSeatPairSettingsFromSheetRow(row);
                rollSeatPairModeIfChanceActive();
                syncMonitorMessagingFromSheetRow(row);

                // Save AreSeatsTogether, Quantity, and login credentials to local storage to avoid name mismatch
                // Try multiple variations of the areaIds column name
                const areaIdsValue = row['areaIds to monitor'] || row['AreaIds to monitor'] || row['areaIds to Monitor'] || 
                                    row.AreaIds || row.areaIds || row['AreaIds'] || row['areaIds'] || '';
                
                // Try multiple variations of the areas to ignore column name
                const areasToIgnoreValue = row['areas to ignore'] || row['Areas to ignore'] || row['Areas to Ignore'] || 
                                          row.AreasToIgnore || row.areasToIgnore || row['AreasToIgnore'] || row['areasToIgnore'] || '';
                
                
                const resaleChancesInit = getResaleEndpointChancesFromRow(row);
                await chrome.storage.local.set({
                    areSeatsTogether: monitor.areSeatsTogether,
                    quantity: monitor.quantity,
                    eventUrl: monitor.eventUrl || '',
                    discordWebhook: monitor.discordWebhook || '',
                    telegramWebhook: monitor.telegramWebhook || '',
                    telegramChatId: monitor.telegramChatId || '',
                    loginEmail: row.LoginEmail || '',
                    loginPassword: row.LoginPassword || '',
                    areaIds: areaIdsValue,
                    areasToIgnore: areasToIgnoreValue,
                    resaleEndpointChances: resaleChancesInit != null ? resaleChancesInit : DEFAULT_RESALE_ENDPOINT_CHANCES,
                    focusRefreshTab: focusRefreshTabFromContentSheetRow(row)
                });
            } else {
                console.warn('[CS] no matching row found in sheet for startSecond', monitor.startSecond);
            }
        }

        // console.warn('[CS] no eventUrl found, will not monitor');
        // return;
    }

    monitor.eventId = extractEventId(monitor.eventUrl || location.href);
    console.log('[CS] using eventId', monitor.eventId);

    if (!monitor.running) {
        monitor.running = true;
        console.log('[CS] starting ======== monitor loop');
        //run immediate check once for first time
        // await alignToStartSecond(monitor.startSecond).catch(e => console.error('[CS] alignToStartSecond error', e));
        // console.log('[CS] aligned to startSecond', monitor.startSecond);
        await checkOnce().catch(e => console.error('[CS] checkOnce error', e));

        scheduleNextCheck(); // first call
    } else {
        console.log('[CS] monitor already running');
    }
}


let lastScheduledTime = null; // stores the planned next run time
let lastRealignTime = null;   // stores the timestamp of the last realignment
let lastRunStartTime = null; // when runCheck() last started (used to log response time)
let nextCheckTimeoutId = null; // single scheduled timeout; clear before setting new one to avoid duplicate API calls per cycle
let runCheckInProgress = false; // guard so only one runCheck (and thus one API call) runs at a time
/** When true, next checkOnce skips the seat GET until refreshEventTabWithTracking confirms eventTabReloaded. */
let pendingSkipSeatFetchEventReloadTimeout = false;

/** Format date as HH:mm:ss.SSS for logs so 80.5 vs 80 are distinguishable. */
function formatTimeWithMs(date) {
    const d = new Date(date);
    const h = String(d.getHours()).padStart(2, '0');
    const m = String(d.getMinutes()).padStart(2, '0');
    const s = String(d.getSeconds()).padStart(2, '0');
    const ms = String(d.getMilliseconds()).padStart(3, '0');
    return `${h}:${m}:${s}.${ms}`;
}

/**
 * Generic formula: next API call = next time (clock seconds) matches extension number in the 12s cycle.
 * - Extension 1  → refresh at :01, :13, :25, :37, :49 (seconds)
 * - Extension 1.5 → refresh at :01.5, :13.5, :25.5, ...
 * - Extension 2  → refresh at :02, :14, :26, ...
 * Formula: (clock sec + ms/1000) % 12 === extensionNumber % 12. Returns ms until that moment.
 */
function getAlignMsToNextInterval(dateNow, startSecondVal, intervalMs) {
    const baseSec = parseFloat(startSecondVal);
    if (Number.isNaN(baseSec)) return intervalMs;
    const baseOffsetMs = ((baseSec * 1000) % intervalMs + intervalMs) % intervalMs;
    const curMsInCycle = (dateNow.getSeconds() * 1000 + dateNow.getMilliseconds()) % intervalMs;
    let alignMs = (baseOffsetMs - curMsInCycle + intervalMs) % intervalMs;
    if (alignMs <= 0) alignMs = intervalMs;
    return alignMs;
}

async function scheduleNextCheck() {
    const waitMs = 12000; // 12s cycle: extension N refreshes when clock (sec % 12) === N (e.g. ext 1 at :01/:13/:25, ext 1.5 at :01.5/:13.5)
    const realignIntervalMs = 120000; // 2 min log only; schedule is always from clock

    // During error403 pause, poll every 5s so we resume quickly when flag clears
    const { error403PauseUntil = 0 } = await chrome.storage.local.get('error403PauseUntil');
    if (error403PauseUntil > 0 && Date.now() < error403PauseUntil) {
        if (!pauseActiveLogged) {
            console.log('[CS] error403 pause is active — seat checks and event tab refresh paused until it ends.');
            pauseActiveLogged = true;
        }
        chrome.runtime.sendMessage({ type: 'heartbeat' }).catch(() => {});
        if (nextCheckTimeoutId != null) clearTimeout(nextCheckTimeoutId);
        nextCheckTimeoutId = setTimeout(() => { nextCheckTimeoutId = null; runCheck(); }, 5000);
        return;
    }
    pauseActiveLogged = false; // pause ended or not active; allow one-time log next time pause is active

    const now = Date.now();

    const base = monitor.startSecond ?? 0;
    const dateNow = new Date();
    // Single formula: next API call = next time clock (sec % 12) matches extension number
    let delay = getAlignMsToNextInterval(dateNow, base, waitMs);
    // After event tab refresh **timed out** (tab never signalled ready), add a cooldown before next API call.
    // Successful reload already waited for verification token — do not add extra delay; stay on 12s clock alignment.
    if (lastEventTabRefreshAt > 0) {
        const minDelayAfterRefresh = minDelayAfterEventTabRefreshMs;
        const elapsedSinceRefresh = now - lastEventTabRefreshAt;
        if (elapsedSinceRefresh < minDelayAfterRefresh) {
            const extraWait = minDelayAfterRefresh - elapsedSinceRefresh;
            delay = Math.max(delay, extraWait);
        }
        lastEventTabRefreshAt = 0;
        minDelayAfterEventTabRefreshMs = 15000;
    }
    // If the next call would happen too soon (<7s), skip to the next 12s cycle so we don't hammer the API,
    // while still keeping alignment to the 12s clock.
    const minGapMs = 7000;
    while (delay < minGapMs) {
        delay += waitMs;
    }
    lastScheduledTime = now + delay;
    if (!lastRealignTime) lastRealignTime = now;

    // Log realignment every 2 min (informational only; schedule is always from clock)
    if (now - lastRealignTime >= realignIntervalMs) {
        console.log(`[CS] Realigning (2 min): next call still bound to extension ${base} at :${(base % 12).toFixed(1)}s in each 12s cycle`);
        lastRealignTime = now;
    }

    const responseTimeMs = typeof lastRunStartTime === 'number' ? now - lastRunStartTime : 0;
    const nextCallAt = new Date(now + delay);
    const delaySec = (delay / 1000).toFixed(2);
    const timeStr = formatTimeWithMs(nextCallAt);
    const baseStr = monitor.startSecond != null ? ' startSecond=' + monitor.startSecond : '';
    if (typeof lastRunStartTime === 'number') {
        console.log('[CS] API+processing took ' + (responseTimeMs / 1000).toFixed(2) + 's, next seat API call in ' + delaySec + 's at ' + timeStr + baseStr);
    } else {
        console.log('[CS] Next seat API call in ' + delaySec + 's at ' + timeStr + baseStr);
    }
    chrome.runtime.sendMessage({type: "heartbeat"});
    if (nextCheckTimeoutId != null) clearTimeout(nextCheckTimeoutId);
    nextCheckTimeoutId = setTimeout(() => { nextCheckTimeoutId = null; runCheck(); }, delay);
}

async function runCheck() {
    if (runCheckInProgress) return; // prevent duplicate API calls when two timeouts or resume fire close together
    runCheckInProgress = true;
    try {
        lastRunStartTime = Date.now();
        await checkOnce().catch(e => console.error('[CS] checkOnce err', e));
        if (monitor.running) scheduleNextCheck();
    } finally {
        runCheckInProgress = false;
    }
}


function extractEventId(url) {
    try {
        const m = (url || '').match(/\/Event\/Index\/(\d+)/);
        if (m) return parseInt(m[1], 10);
        const m2 = (url || '').match(/eventid=(\d+)/i);
        if (m2) return parseInt(m2[1], 10);
        return null;
    } catch (e) {
        return null;
    }
}

async function alignToStartSecond(startSec) {
    const now = new Date();
    const curSec = now.getSeconds();
    let waitMs = 0;
    if (startSec === undefined || startSec === null) startSec = 2;
    if (curSec === startSec) waitMs = 0;
    else if (curSec < startSec) waitMs = (startSec - curSec) * 1000;
    else waitMs = ((60 - curSec) + startSec) * 1000;
    console.log(`[CS] aligning to second ${startSec}. waiting ${waitMs / 1000}s`);
    return new Promise(resolve => setTimeout(resolve, waitMs));
}

/** Google Sheet column "Resale Endpoint Chances": 100 = always resale, 50 = ~50% resale / ~50% regular, 0 = always regular. Missing column → null (caller uses DEFAULT_RESALE_ENDPOINT_CHANCES). */
function getResaleEndpointChancesFromRow(row) {
    if (!row) return null;
    const raw = row['Resale Endpoint Chances'] ?? row['resale endpoint chances'] ?? row.ResaleEndpointChances ?? row.resaleEndpointChances;
    if (raw === '' || raw == null || String(raw).trim() === '') return null;
    const n = parseFloat(String(raw).replace(/%/g, '').trim());
    if (!Number.isFinite(n)) return null;
    return Math.min(100, Math.max(0, n));
}

/**
 * Google Sheet "Pair check chance": empty → null (use AreSeatsTogether + Quantity as written).
 * 0–100: each time this runs, with probability pct% use AreSeatsTogether=true & Quantity=2, else false & 1.
 * 100 = always pair (ignores the AreSeatsTogether / Quantity cells for that roll).
 */
function getPairCheckChanceFromRow(row) {
    if (!row) return null;
    const raw = row['Pair check chance'] ?? row['Pair Check Chance'] ?? row['pair check chance'] ?? row.PairCheckChance ?? row.pairCheckChance;
    if (raw === '' || raw == null || String(raw).trim() === '') return null;
    const n = parseFloat(String(raw).replace(/%/g, '').trim());
    if (!Number.isFinite(n)) return null;
    return Math.min(100, Math.max(0, n));
}

/** Event URL from sheet row (header name variants). */
function eventUrlFromSheetRow(row) {
    if (!row) return '';
    const u = row.EventUrl ?? row['Event URL'] ?? row['event url'] ?? row.EventURL ?? row.eventUrl;
    if (u == null) return '';
    return String(u).trim();
}

/** Sheet → monitor: DiscordWebhook, TelegramBotToken (stored as telegramWebhook), TelegramChatID. Empty cell clears that field. */
function syncMonitorMessagingFromSheetRow(row) {
    if (!row) return;
    if (row.DiscordWebhook !== undefined) {
        monitor.discordWebhook = String(row.DiscordWebhook ?? '').trim();
    }
    if (row.TelegramBotToken !== undefined || row.TelegramWebhook !== undefined) {
        monitor.telegramWebhook = String(row.TelegramBotToken ?? row.TelegramWebhook ?? '').trim();
    }
    if (row.TelegramChatID !== undefined || row.TelegramChatId !== undefined) {
        monitor.telegramChatId = String(row.TelegramChatID ?? row.TelegramChatId ?? '').trim();
    }
}

/** Reads sheet row: stores pair-check %; if empty, applies AreSeatsTogether + Quantity from sheet. */
function syncSeatPairSettingsFromSheetRow(row) {
    monitor.pairCheckChancePct = getPairCheckChanceFromRow(row);
    if (monitor.pairCheckChancePct == null) {
        monitor.areSeatsTogether = row.AreSeatsTogether === true || ('' + row.AreSeatsTogether).toLowerCase() === 'true';
        monitor.quantity = parseInt(row.Quantity || '1', 10);
    }
}

/** Sheet column "Focus Refresh tab?" (any casing/spacing): No/false/0 → background-only refresh; empty/Yes/other → focus when refreshing. */
function focusRefreshTabFromContentSheetRow(row) {
    if (!row || typeof row !== 'object') return true;
    let v;
    for (const key of Object.keys(row)) {
        const norm = String(key).replace(/\s+/g, '').replace(/\?/g, '').toLowerCase();
        if (norm === 'focusrefreshtab') {
            v = row[key];
            break;
        }
    }
    if (v == null || String(v).trim() === '') return true;
    const s = String(v).trim().toLowerCase();
    if (s === 'no' || s === 'false' || s === '0') return false;
    return true;
}

/** When Pair check chance is set, roll every seat API cycle (pair = true & 2, else false & 1). */
function rollSeatPairModeIfChanceActive() {
    const pct = monitor.pairCheckChancePct;
    if (pct == null) return;
    if (Math.random() * 100 < pct) {
        monitor.areSeatsTogether = true;
        monitor.quantity = 2;
    } else {
        monitor.areSeatsTogether = false;
        monitor.quantity = 1;
    }
}

async function getMatchingRowFromSheet(sheetUrl, startSecond) {
    try {
        // Extract sheet ID and gid
        const m = sheetUrl.match(/\/d\/([a-zA-Z0-9-_]+)/);
        if (!m) throw new Error('Invalid sheet URL');
        const sheetId = m[1];
        let gidMatch = sheetUrl.match(/[?&]gid=(\d+)/);
        const gid = gidMatch ? gidMatch[1] : '0';

        // Build GViz URL
        const gviz = `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:json&gid=${gid}`;
        const res = await fetch(gviz);
        const txt = await res.text();

        // Parse JSON from GViz format
        const jsonText = txt.replace(/^[^\{]+/, '').replace(/\);?$/, '');
        const obj = JSON.parse(jsonText);

        const table = obj.table;
        if (!table || !table.rows) throw new Error('No table data found');

        // Headers
        const headers = table.cols.map(c => (c.label || '').trim());

        let rowMatchedButOff = false;
        // Iterate rows
        for (const row of table.rows) {
            const values = (row.c || []).map(cell => cell ? cell.v : '');
            const rowData = {};
            headers.forEach((h, i) => {
                rowData[h] = values[i];
            });

            // Check match (startSecond can be decimal, e.g. 2.5; compare as float)
            const status = (rowData.Status || '').toString().trim().toLowerCase();
            const sheetSecond = parseFloat(rowData.StartSecond);
            const matchSecond = Number.isNaN(sheetSecond) ? null : sheetSecond;
            const configSecond = parseFloat(startSecond);
            const match = (matchSecond != null && !Number.isNaN(configSecond) && matchSecond === configSecond);
            if (match) {
                if (['off', '0', 'false', 'stop'].includes(status)) {
                    console.log('[CS] found matching row but status is Off, will not monitor');
                    rowMatchedButOff = true;
                    continue; // skip this row
                }
            }
            if (status === 'on' && match) {
                // console.log('[CS] Found matching row data:', rowData);
                return rowData; // Found matching row
            }

        }
        if (rowMatchedButOff) {
            console.log('[CS] found matching row for startSecond', startSecond, 'but status is Off, will not monitor');
            stopMonitoring('sheet status is Off');
            return null; // matched but off, stop monitoring
        }

        return null; // No match found
    } catch (err) {
        console.error('Error reading sheet:', err);
        return null;
    }
}

let checksheet = true;//read sheet one time and not next and so on

// Separate error counters for different error types
let error403Count = 0;           // For 403 Forbidden errors
/** Each time we hit 6 consecutive seat 403s without a 200, backoff grows: 70s, 140s, … capped at 5 min. Reset on 200. */
let six403BackoffTier = 0;
const SIX_403_BACKOFF_BASE_MS = 70 * 1000;
const SIX_403_BACKOFF_MAX_MS = 5 * 60 * 1000;
let lastEventTabRefreshAt = 0;  // set only when event tab reload **times out** — then next API waits minDelayAfterEventTabRefreshMs
let minDelayAfterEventTabRefreshMs = 15000; // cooldown after failed reload wait (successful reload uses 12s alignment only)
let tunnelTimeoutErrorCount = 0; // For tunnel connection and timeout errors
let corsErrorCount = 0;          // For CORS errors
let notfound400erorsCount = 0;   // For other HTTP errors (400, 401, 402, 302, 500)
let pauseActiveLogged = false;   // one-time log when error403 pause is active; reset when pause ends to avoid log spam

async function tryDirectAddToBasketSecondapi(data, clubname, eventId, verificationToken, endpointType = 'Regular') {
    let successCount = 0;       // Track successful adds
    let totalFetchCount = 0;    // Track total fetch attempts
    
    // Get PriceClassId for this club
    const priceClassId = getPriceClassIdForClub(clubname);

    const { areaIds, areasToIgnore } = await chrome.storage.local.get(['areaIds', 'areasToIgnore']);
    let allowedSet = null;
    if (areaIds && String(areaIds).trim() !== '') {
        const arr = String(areaIds).split(',').map(id => parseInt(id.trim(), 10)).filter(id => !isNaN(id));
        allowedSet = arr.length ? new Set(arr) : null;
    }
    let ignoredSet = null;
    if (areasToIgnore && String(areasToIgnore).trim() !== '') {
        const arr = String(areasToIgnore).split(',').map(id => parseInt(id.trim(), 10)).filter(id => !isNaN(id));
        ignoredSet = arr.length ? new Set(arr) : null;
    }
    const toAreaIdNum = (v) => { const n = Number(v); return isNaN(n) ? null : n; };
    const areasToTry = data.filter(area => {
        const id = toAreaIdNum(area.AreaId);
        if (id == null) return false;
        if (allowedSet && !allowedSet.has(id)) return false;
        if (ignoredSet && ignoredSet.has(id)) return false;
        return true;
    });
    if (areasToTry.length === 0) return false;

    for (let a = areasToTry.length - 1; a >= 0; a--) {
        const area = areasToTry[a];

        for (const priceBand of area.PriceBands) {
            for (const interval of priceBand.AvailableSeatsIntervals) {

                // Loop through all seats from StartXCoord to EndXCoord
                for (let x = interval.StartXCoord; x <= interval.EndXCoord; x++) {

                    if (totalFetchCount >= 4) {
                        return successCount > 0;
                    }

                    const seatPayload = {
                        EventId: eventId,
                        Seats: [
                            {
                                AreaId: area.AreaId,
                                XCoordinate: x,
                                YCoordinate: interval.YCoord,
                                PriceClassId: priceClassId,
                                IsSecondaryMarket: endpointType === 'Resale'
                            }
                        ]
                    };

                    try {
                        totalFetchCount++;
                        const res = await fetch(`https://www.eticketing.co.uk/${clubname}/EDP/Ism/Select${endpointType}Seat`, {
                            method: "PUT",
                            credentials: "include",
                            headers: {
                                "Accept": "application/json, text/plain, */*",
                                "Content-Type": "application/json",
                                "X-Requested-With": "XMLHttpRequest",
                                "RequestVerificationToken": verificationToken
                            },
                            body: JSON.stringify(seatPayload)
                        });

                        if (res.status === 400) {
                            await res.text();
                        } else if (res.status === 200) {
                            await res.text();
                            successCount++;
                            if (successCount >= 3) return true;
                        }
                    } catch (err) {
                        // silent during try loop for speed
                    }
                }
            }
        }
    }

    // No log here (hot path); outcome logged by caller after basket flow completes or fails
    return successCount > 0; // True if at least one success
}

let queueItErrorCount = 0;  // track consecutive queue-it redirect errors

function parseBasketHtml(html) {
    try {
        // Create a temporary DOM parser
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        
        const basketEvents = [];
        const basketEventElements = doc.querySelectorAll('.basket-event');
        
        basketEventElements.forEach((eventElement, index) => {
            const itemRef = eventElement.getAttribute('basket-event-item-ref');
            const eventTitle = eventElement.querySelector('.basket-event__title')?.textContent?.trim();
            
            // Get seat details
            const areaElement = eventElement.querySelector('[data-testid="seat-detail-area"] .checkout-event-seat-details__value');
            const blockElement = eventElement.querySelector('[data-testid="seat-detail-block"] .checkout-event-seat-details__value');
            const rowElement = eventElement.querySelector('[data-testid="seat-detail-row"] .checkout-event-seat-details__value');
            const seatElement = eventElement.querySelector('[data-testid="seat-detail-seat-number"] .checkout-event-seat-details__value');
            
            // Get price class
            const priceClassElement = eventElement.querySelector('[data-testid="seat-price-class"] dd');
            
            // Get price
            const priceElement = eventElement.querySelector(`#basket-item-price-${itemRef}`);
            
            const seatData = {
                itemRef: itemRef,
                eventTitle: eventTitle,
                area: areaElement?.textContent?.trim(),
                block: blockElement?.textContent?.trim(),
                row: rowElement?.textContent?.trim(),
                seat: seatElement?.textContent?.trim(),
                priceClass: priceClassElement?.textContent?.trim(),
                price: priceElement?.textContent?.trim()
            };
            
            basketEvents.push(seatData);
        });
        
        return {
            events: basketEvents,
            totalEvents: basketEvents.length
        };
    } catch (e) {
        console.error('[CS] Error parsing basket HTML:', e);
        return { events: [], totalEvents: 0 };
    }
}

function shouldSendNotificationBasedOnSeats(basketData) {
    if (!basketData || basketData.events.length === 0) {
        console.log('[CS] No basket events found, will send notification');
        return { shouldSend: true, pairs: [], pairCount: 0 };
    }
    
    const events = basketData.events;
    console.log('[CS] Analyzing', events.length, 'basket events for pair detection');
    
    // Group seats by block and row to find pairs
    const seatGroups = {};
    events.forEach(event => {
        const key = `${event.block}-${event.row}`;
        if (!seatGroups[key]) {
            seatGroups[key] = [];
        }
        seatGroups[key].push({
            ...event,
            seatNumber: parseInt(event.seat) || 0
        });
    });
    
    // Find pairs (adjacent seats in same block and row)
    const pairs = [];
    Object.values(seatGroups).forEach(group => {
        // Sort by seat number
        group.sort((a, b) => a.seatNumber - b.seatNumber);
        
        // Find adjacent seats
        for (let i = 0; i < group.length - 1; i++) {
            if (group[i + 1].seatNumber === group[i].seatNumber + 1) {
                pairs.push({
                    seat1: group[i],
                    seat2: group[i + 1],
                    block: group[i].block,
                    row: group[i].row
                });
                i++; // Skip next seat as it's already paired
            }
        }
    });
    
    const pairCount = pairs.length;
    console.log('[CS] Found', pairCount, 'pairs:', pairs);
    
    // Always send notification, but include pair information
    const shouldSend = true;
    console.log('[CS] Should send notification:', shouldSend, '(always send, pairs found:', pairCount, ')');
    
    return { shouldSend, pairs, pairCount };
}

// Helper function to get email for notifications (prefer sheet-backed loginEmail so Discord shows current account after sheet update)
async function getEmailForNotification() {
    try {
        console.log('[CS] Getting email for notification...');
        const EMAIL_KEY = "user_email";

        // Method 1: chrome.storage.local (loginEmail from Google Sheet - updated when sheet/popup changes)
        const storageData = await chrome.storage.local.get(['loginEmail']);
        if (storageData.loginEmail && storageData.loginEmail.trim()) {
            console.log('[CS] Email from storage (sheet):', storageData.loginEmail.substring(0, 5) + '...');
            return storageData.loginEmail.trim();
        }

        // Method 2: Google Sheet directly (if storage not yet set)
        if (monitor.sheetUrl && monitor.startSecond) {
            try {
                const matched_row = await getMatchingRowFromSheet(monitor.sheetUrl, monitor.startSecond);
                if (matched_row && matched_row.LoginEmail && matched_row.LoginEmail.trim()) {
                    console.log('[CS] Email from sheet:', matched_row.LoginEmail.substring(0, 5) + '...');
                    await chrome.storage.local.set({ loginEmail: matched_row.LoginEmail });
                    return matched_row.LoginEmail.trim();
                }
            } catch (e) {
                console.warn('[CS] Error getting email from sheet:', e.message);
            }
        }

        // Method 3: Refresh credentials from background then storage
        try {
            const response = await new Promise((resolve, reject) => {
                chrome.runtime.sendMessage({ action: 'refreshCredentials' }, (response) => {
                    if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                    else resolve(response);
                });
            });
            if (response && response.success) {
                const refreshedData = await chrome.storage.local.get(['loginEmail']);
                if (refreshedData.loginEmail && refreshedData.loginEmail.trim()) {
                    console.log('[CS] Email after refresh:', refreshedData.loginEmail.substring(0, 5) + '...');
                    return refreshedData.loginEmail.trim();
                }
            }
        } catch (e) {
            console.warn('[CS] Error refreshing credentials:', e.message);
        }

        // Method 4: localStorage (legacy / from page scrape - may be stale after sheet update)
        const userEmail = localStorage.getItem(EMAIL_KEY);
        if (userEmail && userEmail.trim()) {
            console.log('[CS] Email from localStorage (fallback):', userEmail.substring(0, 5) + '...');
            return userEmail.trim();
        }

        console.warn('[CS] No email from any source, returning "Unknown Email"');
        return "Unknown Email";
    } catch (e) {
        console.error('[CS] Error getting email for notification:', e);
        return "Unknown Email";
    }
}

/** Strip HTML from lock/error responses; preserve line breaks where possible (e.g. ticket limit messages). */
function plainTextFromLockApiBody(raw) {
    if (raw == null || typeof raw !== 'string') return '';
    return raw
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/(p|div|h[1-6]|li)\s*>/gi, '\n')
        .replace(/<[^>]+>/g, '')
        .replace(/&nbsp;/gi, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .split('\n')
        .map((s) => s.replace(/\s+/g, ' ').trim())
        .filter(Boolean)
        .join('\n')
        .trim();
}

/** Read `fetch` response body once; normalize HTML or plain text for notifications. */
async function plainTextFromFetchResponse(res) {
    if (!res || typeof res.text !== 'function') return '';
    try {
        return plainTextFromLockApiBody(await res.text());
    } catch (_) {
        return '';
    }
}

/** IIS / long HTML errors: keep only text before "Most likely causes:" so Discord stays readable. */
function clipLockApiBodyForDiscord(plain) {
    let s = String(plain).trim();
    const re = /most likely causes:/i;
    const m = re.exec(s);
    if (m) s = s.slice(0, m.index).trim();
    return s.replace(/\s+$/, '');
}

/** Non-empty API body snippet for Discord (capped length for webhook limits). */
function discordResponseBodySection(label, plain) {
    if (!plain || !String(plain).trim()) return '';
    const max = 1800;
    let s = clipLockApiBodyForDiscord(String(plain));
    if (!s) return '';
    if (s.length > max) s = s.slice(0, max) + '\n… (truncated)';
    return '\n📄 **' + label + ':**\n' + s;
}

/** Event ID + URL for every Discord/Telegram error (monitor may omit URL briefly — still show "(not set)"). */
function formatNotificationEventContext() {
    const u = (monitor.eventUrl || '').trim();
    const idRaw = monitor.eventId;
    const id = idRaw != null && String(idRaw).trim() !== '' ? String(idRaw).trim() : '';
    let s = '';
    if (id) s += '\n🆔 **Event ID:** ' + id;
    s += '\n🔗 **Event URL:** ' + (u || '(not set)');
    return s;
}

async function checkOnce() {
    if (!monitor.running) return;

    // Pause seat checking during queue error403 wait (5 min)
    const { error403PauseUntil = 0 } = await chrome.storage.local.get('error403PauseUntil');
    if (error403PauseUntil > 0 && Date.now() < error403PauseUntil) {
        if (!pauseActiveLogged) {
            console.log('[CS] error403 pause is active — seat checks and event tab refresh paused until it ends.');
            pauseActiveLogged = true;
        }
        return;
    }

    const storageSnap = await chrome.storage.local.get(['eventUrl', 'startSecond']);
    const storedEv = (storageSnap.eventUrl || '').trim();
    if (storedEv && storedEv !== (monitor.eventUrl || '').trim()) {
        monitor.eventUrl = storedEv;
        monitor.eventId = extractEventId(storedEv);
        console.log('[CS] eventUrl synced from storage (e.g. sheet poll while monitoring)');
    }
    if (storageSnap.startSecond != null && storageSnap.startSecond !== '') {
        const ss = parseFloat(storageSnap.startSecond);
        if (!Number.isNaN(ss) && ss !== monitor.startSecond) {
            monitor.startSecond = ss;
        }
    }

    let matched_row = null;
    if (checksheet) {
        matched_row = await getMatchingRowFromSheet(monitor.sheetUrl, monitor.startSecond);
        if (matched_row) {
            const sheetEv = eventUrlFromSheetRow(matched_row);
            if (sheetEv) {
                monitor.eventUrl = sheetEv;
                monitor.eventId = extractEventId(sheetEv);
            }
            syncSeatPairSettingsFromSheetRow(matched_row);
            syncMonitorMessagingFromSheetRow(matched_row);

            // Save AreSeatsTogether, Quantity, and login credentials to local storage to avoid name mismatch
            // Try multiple variations of the areaIds column name
            const areaIdsValue = matched_row['areaIds to monitor'] || matched_row['AreaIds to monitor'] || matched_row['areaIds to Monitor'] || 
                                matched_row.AreaIds || matched_row.areaIds || matched_row['AreaIds'] || matched_row['areaIds'] || '';
            
            // Try multiple variations of the areas to ignore column name
            const areasToIgnoreValue = matched_row['areas to ignore'] || matched_row['Areas to ignore'] || matched_row['Areas to Ignore'] || 
                                      matched_row.AreasToIgnore || matched_row.areasToIgnore || matched_row['AreasToIgnore'] || matched_row['areasToIgnore'] || '';
            
            const resaleChances = getResaleEndpointChancesFromRow(matched_row);
            await chrome.storage.local.set({
                loginEmail: matched_row.LoginEmail || '',
                loginPassword: matched_row.LoginPassword || '',
                eventUrl: monitor.eventUrl || '',
                discordWebhook: monitor.discordWebhook || '',
                telegramWebhook: monitor.telegramWebhook || '',
                telegramChatId: monitor.telegramChatId || '',
                areaIds: areaIdsValue,
                areasToIgnore: areasToIgnoreValue,
                resaleEndpointChances: resaleChances != null ? resaleChances : DEFAULT_RESALE_ENDPOINT_CHANCES,
                focusRefreshTab: focusRefreshTabFromContentSheetRow(matched_row)
            });

            const status = (matched_row.Status || '').toString().trim().toLowerCase();
            console.log('[CS] sheet status', status);

            if (['off', '0', 'false', 'stop'].includes(status)) {
                console.log('[CS] sheet status is Off, stopping monitoring');
                stopMonitoring('sheet status is Off');
                return;
            } else if (!['on', 'start', 'true', '1'].includes(status)) {
                console.warn('[CS] unknown sheet status:', status);
            }
        }
        checksheet = false;
    } else {
        checksheet = true;
    }

    rollSeatPairModeIfChanceActive();
    await chrome.storage.local.set({
        areSeatsTogether: monitor.areSeatsTogether,
        quantity: monitor.quantity != null ? monitor.quantity : 1
    });

    if (!monitor.eventId) {
        monitor.eventId = extractEventId(monitor.eventUrl || location.href);
        if (!monitor.eventId) {
            console.warn('[CS] no eventId, will not check');
            return;
        }
    }

    function getClubName(url) {
        const parts = url.split('/');
        return parts[3];
    }

    const clubName = getClubName(monitor.eventUrl);
    const { resaleEndpointChances: storedResalePct } = await chrome.storage.local.get(['resaleEndpointChances']);
    let resalePct = parseFloat(storedResalePct);
    if (!Number.isFinite(resalePct)) resalePct = DEFAULT_RESALE_ENDPOINT_CHANCES;
    resalePct = Math.min(100, Math.max(0, resalePct));
    const isResale = Math.random() * 100 < resalePct;
    const endpointType = isResale ? 'Resale' : 'Regular';
    const marketTypeParam = isResale ? '&MarketType=1' : '';
    const url = `https://www.eticketing.co.uk/${clubName}/EDP/Seats/Available${endpointType}?AreSeatsTogether=${monitor.areSeatsTogether}&EventId=${monitor.eventId}${marketTypeParam}&MaximumPrice=10000000&MinimumPrice=0&Quantity=${monitor.quantity}`;

    const seatsCheckEndpointLabel = endpointType;
    let seatsCheckHttpStatus = null;
    const logSeatsOutcome = (detail) => {
        const http = seatsCheckHttpStatus != null ? String(seatsCheckHttpStatus) : 'n/a';
        const q = monitor.quantity != null ? monitor.quantity : '?';
        console.log('[CS] ' + detail + ' | Seats check: ' + seatsCheckEndpointLabel + ', HTTP ' + http + ', quantity: ' + q);
    };

    if (pendingSkipSeatFetchEventReloadTimeout) {
        console.log('[CS] Event tab reload was not confirmed earlier — retrying refresh before seat API (no GET until flag is set).');
        const recovered = await refreshEventTabWithTracking();
        if (!recovered) {
            logSeatsOutcome('Skipped seat API — event tab reload not confirmed (retry again next cycle)');
            return;
        }
    }

    let res;
    try {
        res = await fetch(url, {
            method: 'GET',
            headers: {
                "accept": "application/json, text/plain, */*",
                "x-requested-with": "XMLHttpRequest",
                "referer": location.href
            },
            credentials: "include"
        });
        seatsCheckHttpStatus = res.status;

        // Reset queue-it error count on successful fetch
        // queueItErrorCount = 0;

        // Detect if redirected to queue (queue-it.net or hd-queue.eticketing.co.uk)
        if (res.url.includes('queue-it.net') || res.url.includes('hd-queue.eticketing.co.uk')) {
            queueItErrorCount++;
            console.warn('[CS] Redirected to queue page, count:', queueItErrorCount);

            if (queueItErrorCount >= 1) {
                console.warn('[CS] 1 consecutive queue-it redirects (count:', queueItErrorCount, '), refreshing...');
                chrome.runtime.sendMessage({action: 'closeOtherTabsExcept'});
                const refreshed = await refreshEventTabWithTracking();
                queueItErrorCount = 0; // always reset; if pause blocked refresh we backoff (unblocked time only)
                if (!refreshed) {
                    console.log(
                        '[CS] Refresh blocked by pause — waiting ' +
                            BACKOFF_UNBLOCKED_MS_AFTER_REFRESH_BLOCKED / 1000 +
                            's unblocked (queue / error403 pause excluded) before continuing.'
                    );
                    await delayUnblockedMs(BACKOFF_UNBLOCKED_MS_AFTER_REFRESH_BLOCKED);
                }
                logSeatsOutcome('Redirected to queue');
                return;
            }
        } else {
            // If not queue-it redirect, reset count
            queueItErrorCount = 0;
        }
    } catch (e) {
        console.error('[CS] fetch seats error', e);

        // Detect CORS / Failed to fetch case
        if (e instanceof TypeError && e.message.includes('Failed to fetch')) {
            console.warn('[CS] Failed to fetch error detected');

            // We need to distinguish between different types of "Failed to fetch" errors:
            // 1. CORS errors: Usually happen when redirected to queue-it.net
            // 2. Tunnel connection errors: Network connectivity issues (ERR_TUNNEL_CONNECTION_FAILED)
            // 3. Other network errors: Timeouts, DNS issues, etc.
            
            // The challenge is that both CORS and tunnel errors result in "Failed to fetch"
            // but have different underlying causes. Since we can't access the detailed error
            // from the JavaScript error object, we need a different approach.
            
            // One approach is to use timing or other heuristics, but for now,
            // let's be more conservative and treat most "Failed to fetch" errors as
            // tunnel/network errors, unless we have strong evidence they're CORS errors.
            
            // We'll only treat as CORS errors if we can definitively identify them.
            // For now, let's treat all "Failed to fetch" as tunnel errors to avoid
            // false positives, and rely on the redirect detection logic above
            // to catch actual CORS errors.
            
            tunnelTimeoutErrorCount++;
            console.warn('[CS] Cors or network or Tunnel connection or timeout error detected, count:', tunnelTimeoutErrorCount);
            
            if (tunnelTimeoutErrorCount >= 2) {
                console.warn('[CS] 2 consecutive tunnel/timeout errors (count:', tunnelTimeoutErrorCount, '), refreshing...');
                chrome.runtime.sendMessage({action: 'closeOtherTabsExcept'});
                const refreshed = await refreshEventTabWithTracking();
                tunnelTimeoutErrorCount = 0; // always reset; if pause blocked refresh we backoff (unblocked time only)
                if (!refreshed) {
                    console.log(
                        '[CS] Failed-to-fetch / CORS-like path: refresh blocked by pause — waiting ' +
                            BACKOFF_UNBLOCKED_MS_AFTER_REFRESH_BLOCKED / 1000 +
                            's unblocked (queue / error403 pause excluded) before continuing.'
                    );
                    await delayUnblockedMs(BACKOFF_UNBLOCKED_MS_AFTER_REFRESH_BLOCKED);
                }
                logSeatsOutcome('Tunnel/timeout — refresh triggered');
                return;
            }
        } else {
            // reset on other errors
            queueItErrorCount = 0;
        }

        notfound400erorsCount++;
        logSeatsOutcome('Seats API fetch failed (see error above)');
        return;
    }

    // Only reset all error counters on successful 200 status
    if (res.status === 200) {
        error403Count = 0;
        six403BackoffTier = 0;
        tunnelTimeoutErrorCount = 0;
        corsErrorCount = 0;
        notfound400erorsCount = 0;
        queueItErrorCount = 0;
    }

    // Handle 403 errors separately
    if (res.status === 403) {
        error403Count++;
        console.warn('[CS] received 403 Forbidden error from check seats availability API, count:', error403Count);

        // At 3 consecutive 403s: refresh event tab; wait up to 60s unblocked time for reload flag; if missing, refresh again
        if (error403Count === 3) {
            console.warn('[CS] 3 consecutive 403 errors — refresh event tab + wait for reload flag (60s unblocked; queue/pause pauses timer).');
            logSeatsOutcome('403 — refresh at 3 consecutive');
            await handleThreeConsecutiveSeat403Refresh();
            return;
        }

        if (error403Count >= 6) {
            six403BackoffTier += 1;
            const waitMs = Math.min(SIX_403_BACKOFF_MAX_MS, SIX_403_BACKOFF_BASE_MS * six403BackoffTier);
            const waitSec = Math.round(waitMs / 1000);
            console.warn(
                `[CS] 6 consecutive 403 errors — waiting ${waitSec}s before seat API resumes (backoff tier ${six403BackoffTier}, cap ${SIX_403_BACKOFF_MAX_MS / 1000}s). No cookie clear.`
            );
            logSeatsOutcome(`403×6 — backoff ${waitSec}s (tier ${six403BackoffTier})`);
            await delay(waitMs);
            error403Count = 0;
        }

        logSeatsOutcome('403 Forbidden on seats check');
        return;
    }

    // Handle other HTTP errors (400, 401, 402, 302, 500)
    const otherErrorStatuses = [400, 401, 402, 302, 500];
    if (otherErrorStatuses.includes(res.status)) {
        notfound400erorsCount++;
        console.warn('[CS] received error status from check seats availability API:', res.status, ', count:', notfound400erorsCount);
        logSeatsOutcome('Seats check HTTP ' + res.status);

        // If reached 4 errors -> refresh
        if (notfound400erorsCount === 4) {
            console.warn('[CS] 4 consecutive other errors (count:', notfound400erorsCount, ') — refreshing tab.');
            const refreshed = await refreshEventTabWithTracking();
            if (!refreshed) {
                notfound400erorsCount = 0;
                console.log('[CS] Refresh blocked by pause — waiting 60s before continuing.');
                await delay(60000);
            }
        }

        // If reached 7 errors -> clear cookies + refresh
        if (notfound400erorsCount >= 7) {
            console.warn('[CS] 7 or more consecutive other errors (count:', notfound400erorsCount, ') — requesting cookie clear & refresh.');
            chrome.runtime.sendMessage({action: "clearCookiesAndRefresh"});
            await delay(2000);
            const refreshed = await refreshEventTabWithTracking();
            notfound400erorsCount = 0; // always reset; if pause blocked refresh we wait 60s below
            if (!refreshed) {
                console.log('[CS] Refresh blocked by pause — waiting 60s before continuing.');
                await delay(60000);
            }
        }

        return;
    }

    let data;
    try {
        data = await res.json();
    } catch (e) {
        console.warn('[CS] seats response JSON parse failed', e);
        logSeatsOutcome('Seats response JSON parse failed');
        return;
    }

    if (!Array.isArray(data) || data.length === 0) {
        logSeatsOutcome('No areas returned (seat not found)');
        return;
    }

    const { areaIds, areasToIgnore } = await chrome.storage.local.get(['areaIds', 'areasToIgnore']);
    let allowedSet = null;
    if (areaIds && String(areaIds).trim() !== '') {
        const arr = String(areaIds).split(',').map(id => parseInt(id.trim(), 10)).filter(id => !isNaN(id));
        allowedSet = arr.length ? new Set(arr) : null;
    }
    let ignoredSet = null;
    if (areasToIgnore && String(areasToIgnore).trim() !== '') {
        const arr = String(areasToIgnore).split(',').map(id => parseInt(id.trim(), 10)).filter(id => !isNaN(id));
        ignoredSet = arr.length ? new Set(arr) : null;
    }

    const toAreaIdNum = (v) => { const n = Number(v); return isNaN(n) ? null : n; };
    const allAreaIds = data.map(a => toAreaIdNum(a.AreaId)).filter(id => id != null);
    let area = null;
    for (let i = 0; i < data.length; i++) {
        const a = data[i];
        if (!a.PriceBands || !a.PriceBands.length) continue;
        const id = toAreaIdNum(a.AreaId);
        if (id == null) continue;
        if (allowedSet && !allowedSet.has(id)) continue;
        if (ignoredSet && ignoredSet.has(id)) continue;
        area = a;
        break;
    }
    if (!area && (allowedSet || ignoredSet)) {
        const allowedList = allowedSet ? Array.from(allowedSet) : [];
        const ignoredList = ignoredSet ? Array.from(ignoredSet) : [];
        console.log('\n[CS] Seats API areas returned:', allAreaIds.length ? allAreaIds.join(', ') : '(none)');
        console.log('[CS] Seats monitor areaIds (filter):', allowedList.length ? allowedList.join(', ') : '(none)');
        console.log('[CS] Seats ignore areaIds:', ignoredList.length ? ignoredList.join(', ') : '(none)');

        if (allowedSet) {
            logSeatsOutcome('No area matches monitor filter (API returned ' + data.length + ' areas)');
            return;
        }
        area = data.find(a => {
            const id = toAreaIdNum(a.AreaId);
            return id != null && a.PriceBands && a.PriceBands.length && (!ignoredSet || !ignoredSet.has(id));
        }) || null;
        if (!area) {
            logSeatsOutcome('No area matches monitor/ignore after filtering (API returned ' + data.length + ' areas)');
            return;
        }
    }
    // Only fallback to "any area" when there are NO filters configured.
    if (!area && !(allowedSet || ignoredSet)) area = data.find(a => a.PriceBands && a.PriceBands.length) || data[0];
    if (!area) {
        logSeatsOutcome('No area with PriceBands in API response');
        return;
    }

    const priceBand = area.PriceBands[0];
    const areaId = area.AreaId;
    const priceBandId = priceBand.PriceBandCode;

    let verificationToken = localStorage.getItem("verification_token");
    if (!verificationToken) {
        verificationToken = 'MOn7sdIDdiCrtszHY1RszN2HcxXfJZh4u5JWRkfGzwqplL9l_wSMkXYhJl3VRBglbAZvjJqeNQLamfQkFoO78OD1eLA1';
    }

    const lockUrl = `https://www.eticketing.co.uk/${clubName}/EDP/BestAvailable/${endpointType}Seats`;
    const lockBody = {
        EventId: monitor.eventId,
        Quantity: monitor.quantity,
        AreSeatsTogether: monitor.areSeatsTogether,
        AreaId: areaId,
        PriceBandId: priceBandId,
        SeatAttributeIds: [],
        MinimumPrice: 0,
        MaximumPrice: 10000000
    };

    let lockRes;
    try {
        // Step 3: Make the POST request including the token
        lockRes = await fetch(lockUrl, {
            method: 'POST',
            headers: {
                "accept": "application/json, text/plain, */*",
                "accept-language": "en-US,en;q=0.9",
                "content-type": "application/json",
                "origin": "https://www.eticketing.co.uk",
                "referer": monitor.eventUrl,
                "requestverificationtoken": verificationToken,
                "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "\"Windows\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-requested-with": "XMLHttpRequest"
            },
            credentials: "include",
            body: JSON.stringify(lockBody)
        });
    } catch (e) {
        const email = await getEmailForNotification();
        chrome.runtime.sendMessage({
            action: 'notifyErrorWebhooks',
            message: `\n\nError locking seats: ${e.message} for AreaId ${areaId} PriceBandId ${priceBandId}${formatNotificationEventContext()}\n🔢 **Quantity:** ${monitor.quantity}\n👤 **Account:** ${email}`,
            payload: null
        });
        logSeatsOutcome('Lock request failed: ' + e.message);
        return;
    }

    if (lockRes.status === 403) {
        let lock403Plain = '';
        try {
            lock403Plain = plainTextFromLockApiBody(await lockRes.text());
        } catch (e) {
            lock403Plain = '';
        }

        if (!(await tryDirectAddToBasketSecondapi(data, clubName, monitor.eventId, verificationToken, endpointType))) {
            const email = await getEmailForNotification();
            const errorMessage = `🎫 Direct add to basket failed for all areas. Seats were found but could not be added to basket.${formatNotificationEventContext()}\n🔢 **Quantity:** ${monitor.quantity}\n👤 **Account:** ${email}${discordResponseBodySection('Lock API (403) response', lock403Plain)}`;
            chrome.runtime.sendMessage({
                action: 'notifyErrorWebhooks',
                message: errorMessage,
                payload: null
            });
            logSeatsOutcome('Direct add to basket failed (lock was 403)');
            if (lock403Plain) {
                console.log('[CS] Lock API (403) response text:\n' + lock403Plain);
            }
            return;
        }
    } else if (lockRes.status === 400 || lockRes.status === 404) {
        const lockErrPlain = await plainTextFromFetchResponse(lockRes);
        const email = await getEmailForNotification();
        chrome.runtime.sendMessage({
            action: 'notifyErrorWebhooks',
            message: `\n🎫 Seat AreaId ${areaId} PriceBandId ${priceBandId} found but not locked. Status: ${lockRes.status}${formatNotificationEventContext()}\n🔢 **Quantity:** ${monitor.quantity}\n👤 **Account:** ${email}${discordResponseBodySection('Lock API (' + lockRes.status + ') response', lockErrPlain)}`,
            payload: null
        });
        logSeatsOutcome('Lock failed HTTP ' + lockRes.status);
        return;
    } else if (lockRes.status !== 200) {
        const lockErrPlain = await plainTextFromFetchResponse(lockRes);
        const email = await getEmailForNotification();
        chrome.runtime.sendMessage({
            action: 'notifyErrorWebhooks',
            message: `🎫 Error locking seats: ${lockRes.status} for AreaId ${areaId}${formatNotificationEventContext()}\n🔢 **Quantity:** ${monitor.quantity}\n👤 **Account:** ${email}${discordResponseBodySection('Lock API (' + lockRes.status + ') response', lockErrPlain)}`,
            payload: null
        });
        logSeatsOutcome('Lock failed HTTP ' + lockRes.status);
        return;
    } else {

        let lockJson;
        try {
            lockJson = await lockRes.json();
        } catch (e) {
            lockJson = null;
        }

        const lockedSeats = lockJson?.LockedSeats;
        if (!lockedSeats || lockedSeats.length === 0) {
            logSeatsOutcome('Lock HTTP 200 but no LockedSeats in response');
            return;
        }

        const priceClassId = getPriceClassIdForClub(clubName);
        let seatsToAdd;
        if (monitor.areSeatsTogether && monitor.quantity > 1) {
            seatsToAdd = lockedSeats.map(seat => ({ Id: seat.Id, PriceClassId: priceClassId }));
        } else {
            seatsToAdd = [{ Id: lockedSeats[0].Id, PriceClassId: priceClassId }];
        }

        const putBody = { EventId: monitor.eventId, Seats: seatsToAdd };
        let putRes;
        try {
            putRes = await fetch(lockUrl, {
                method: 'PUT',
                headers: {
                    "authority": "www.eticketing.co.uk",
                    "accept": "application/json, text/plain, */*",
                    "accept-encoding": "gzip, deflate, br, zstd",
                    "accept-language": "en-US,en;q=0.9,ur;q=0.8",
                    "content-length": JSON.stringify(putBody).length,

                    "content-type": "application/json",
                    "dnt": "1",
                    "origin": "https://www.eticketing.co.uk",
                    "priority": "u=1, i",
                    "referer": monitor.eventUrl,
                    "requestverificationtoken": verificationToken,
                    "x-requested-with": "XMLHttpRequest"
                },
                credentials: "include",
                body: JSON.stringify(putBody)
            });
        } catch (e) {
            logSeatsOutcome('Add-to-basket request failed before HTTP response');
            return;
        }

        // Check if add to basket failed (not 200 or 201)
        if (putRes.status !== 200 && putRes.status !== 201) {
            const putErrPlain = await plainTextFromFetchResponse(putRes);
            // Get email for notification
            const email = await getEmailForNotification();
            
            // Format seat details from lockedSeats
            const seatDetails = lockedSeats.map((seat, idx) => {
                return `Seat ${idx + 1}: ID ${seat.Id}${seat.AreaId ? `, AreaId ${seat.AreaId}` : ''}${seat.Row ? `, Row ${seat.Row}` : ''}${seat.SeatNumber ? `, Seat ${seat.SeatNumber}` : ''}`;
            }).join('\n');
            
            // Create error message with seat details
            const errorMessage = `❌ **SEAT LOCKED BUT NOT ADDED TO BASKET**
════════════════════════════════════════════════════════════════
🎫 **Status:** Seat locked successfully but failed to add to basket (HTTP ${putRes.status})
🆔 **Event ID:** ${monitor.eventId}
🔗 **Event URL:** ${monitor.eventUrl || '(not set)'}
📍 **Area ID:** ${areaId}
🔢 **Quantity:** ${monitor.quantity}
👤 **Account:** ${email}
            
🎫 **LOCKED SEATS:**
${seatDetails}
${discordResponseBodySection('Basket PUT (HTTP ' + putRes.status + ') response', putErrPlain)}
⚠️ **Action Required:** Please check the basket manually or try again.
════════════════════════════════════════════════════════════════`;
            
            chrome.runtime.sendMessage({
                action: 'notifyErrorWebhooks',
                message: errorMessage,
                payload: null
            });
            logSeatsOutcome('Basket PUT failed HTTP ' + putRes.status);
            // Return early to prevent success notification
            return;
        }
        
        // Ticket successfully added to basket (status 200 or 201) — no console logs until data layer work completes
        
        // Wait 2 seconds before calling GetDataLayer to ensure data is ready
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Get data layer (products added to basket)
        const dlUrl = `https://www.eticketing.co.uk/${clubName}/tagManager/GetDataLayer`;
        let dlRes;
        try {
            dlRes = await fetch(dlUrl, {
                method: 'GET',
                headers: {
                    "authority": "www.eticketing.co.uk",
                    "path": `/${clubName}/tagManager/GetDataLayer`,
                    "scheme": "https",
                    "accept-encoding": "gzip, deflate, br, zstd",
                    "accept": "application/json, " +
                        "text/plain, */*",
                    "accept-language": "en-US,en;q=0.9,ur;q=0.8",
                    "dnt": "1",
                    "priority": "u=1, i",
                    "origin": "https://www.eticketing.co.uk",
                    "x-requested-with": "XMLHttpRequest",
                    "referer": monitor.eventUrl
                },
                credentials: "include"
            });
        } catch (e) {
            // silent during hot path
        }
        let dlJson = null;
        try {
            if (dlRes) dlJson = await dlRes.json();
        } catch (e) {
            // silent during hot path
        }

        //asyn call checkOnce function
        checkOnce().catch(e => console.error('[CS] checkOnce error after one product was added to basket', e));



// const message = `Tickets added to basket for Event ${monitor.eventId}. Seat info: ${JSON.stringify(dlJson?.[0]?.products || [])}`;
// Tickets added to basket for Event 3674. Seat info: [{"kickoff_datetime":"2025-09-06 13:30","category_3":"Club Level Tier 2","position":0,"category_2":"Adult","quantity":1,"price":"39.50","currency":"GBP","seatArea":"46","seatBlock":"46 Club Level","seatRow":"7 ","seatSeat":"122","id":"3674","name":"Arsenal Women v London City Lionesses","category":"Match Tickets","business_line":"eTicketing","filter_event_type":"Away Box Office"}]
// Use email from sheet (storage) so Discord shows current account after sheet update; fallback to localStorage
    const userEmail = (await getEmailForNotification()) || "Unknown Email";

    // Extract information from dataLayer - look for the last basket_viewed event
    let basketData = null;
    let products = [];
    let eventName = "Unknown Event";
    let eventDate = "Unknown Date/Time";
    let totalValue = 0;
    let currency = "GBP";
    let membershipType = "Unknown";
    let crn = "Unknown";
    
    if (dlJson && Array.isArray(dlJson)) {
        // First, try to find product_added_to_basket events (these contain price information)
        const productAddedEvents = dlJson.filter(item => item.event === 'product_added_to_basket');
        if (productAddedEvents.length > 0) {
            // Get the last product_added_to_basket event
            basketData = productAddedEvents[productAddedEvents.length - 1];
            products = basketData.products || [];
            
            // Calculate total value from products (sum of all prices)
            totalValue = products.reduce((sum, product) => {
                const price = parseFloat(product.price || 0);
                return sum + (price * (product.quantity || 1));
            }, 0);
            
            currency = products[0]?.currency || basketData.currency || "GBP";
            membershipType = basketData.membership_type || "Unknown";
            crn = basketData.crn || "Unknown";
            
            if (products.length > 0) {
                eventName = products[0].name || "Unknown Event";
                eventDate = products[0].kickoff_datetime || "Unknown Date/Time";
            }
            
        } else {
            // Fall back to basket_viewed event if product_added_to_basket is not found
            const basketViewedEvents = dlJson.filter(item => item.event === 'basket_viewed');
            if (basketViewedEvents.length > 0) {
                basketData = basketViewedEvents[basketViewedEvents.length - 1]; // Get the last one
                products = basketData.products || [];
                totalValue = basketData.value || 0;
                currency = basketData.currency || "GBP";
                membershipType = basketData.membership_type || "Unknown";
                crn = basketData.crn || "Unknown";
                
                if (products.length > 0) {
                    eventName = products[0].name || "Unknown Event";
                    eventDate = products[0].kickoff_datetime || "Unknown Date/Time";
                }
                
            }
        }
    }
    
    // Check if we need to fall back to basket HTML information
    // This happens when:
    // 1. Products array is empty, OR
    // 2. Products array length doesn't match the quantity (incomplete data)
    let expectedQuantity = 0;
    if (basketData) {
        // For product_added_to_basket events, calculate quantity from products
        if (basketData.event === 'product_added_to_basket' && products.length > 0) {
            expectedQuantity = products.reduce((sum, product) => sum + (product.quantity || 1), 0);
        } else {
            // For basket_viewed events, use the quantity from the event
            expectedQuantity = basketData.quantity || 0;
        }
    }
    const needsFallback = products.length === 0 || (expectedQuantity > 0 && products.length < expectedQuantity);
    
    // Only fetch basket HTML if dataLayer is incomplete
    if (needsFallback) {
        const basketUrl = `https://www.eticketing.co.uk/${clubName}/Checkout/Basket`;
        try {
            const basketRes = await fetch(basketUrl, {
                method: 'GET',
                headers: {
                    "authority": "www.eticketing.co.uk",
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                    "accept-language": "en-US,en;q=0.9,ur;q=0.8",
                    "dnt": "1",
                    "referer": monitor.eventUrl,
                    "x-requested-with": "XMLHttpRequest"
                },
                credentials: "include"
            });
            
            if (basketRes.ok) {
                const basketHtml = await basketRes.text();
                // Parse basket HTML to get seat details
                const basketHtmlData = parseBasketHtml(basketHtml);
                
                if (basketHtmlData.events && basketHtmlData.events.length > 0) {
                    products = basketHtmlData.events.map(event => ({
                        seatBlock: event.block,
                        seatRow: event.row,
                        seatSeat: event.seat,
                        seatArea: event.area,
                        category_2: event.priceClass,
                        price: event.price,
                        currency: "GBP",
                        name: "Unknown Event",
                        kickoff_datetime: "Unknown Date/Time",
                        category_3: event.block && event.block.toLowerCase().includes('club level') ? 'Club Level' : 'General',
                        business_line: "eTicketing",
                        filter_event_type: "Unknown"
                    }));
                    
                    // Set event name and date from monitor if available
                    if (monitor.eventUrl) {
                        eventName = "Event from URL";
                        eventDate = "Unknown Date/Time";
                    }
                }
            }
        } catch (e) {
            /* silent */
        }
    }

    // Build seat info with proper price formatting
    const seatInfo = products.map((p, idx) => {
        const isClubLevel = p.seatBlock && p.seatBlock.toLowerCase().includes('club level');
        const clubLevelIndicator = isClubLevel ? ' 🏆' : '';
        const price = p.price && p.price !== 'undefined' ? p.price : 'N/A';
        const currency = p.currency && p.currency !== 'undefined' ? p.currency : 'GBP';
        return `**[${idx + 1}]** ${p.seatBlock}${clubLevelIndicator} - Row ${p.seatRow} Seat ${p.seatSeat} (${price} ${currency})`;
    }).join("\n");

    const firstProduct = products[0] || {};

// Format current local date & time
    const now = new Date();
    const formattedNow = now.toLocaleString("en-GB", {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    });

// Removed duplicate prevention filter - notifications will be sent every time


    // Detect pairs from products (either dataLayer or basket HTML)
    let pairInfoText = '';
    let basketDetailsText = '';
    
    if (products.length > 0) {
        // Group seats by block and row to find pairs
        const seatGroups = {};
        products.forEach(product => {
            const key = `${product.seatBlock}-${product.seatRow}`;
            if (!seatGroups[key]) {
                seatGroups[key] = [];
            }
            seatGroups[key].push({
                ...product,
                seatNumber: parseInt(product.seatSeat) || 0
            });
        });
        
        // Find pairs (adjacent seats in same block and row)
        const pairs = [];
        Object.values(seatGroups).forEach(group => {
            // Sort by seat number
            group.sort((a, b) => a.seatNumber - b.seatNumber);
            
            // Find adjacent seats
            for (let i = 0; i < group.length - 1; i++) {
                if (group[i + 1].seatNumber === group[i].seatNumber + 1) {
                    pairs.push({
                        seat1: group[i],
                        seat2: group[i + 1],
                        block: group[i].seatBlock,
                        row: group[i].seatRow
                    });
                    i++; // Skip next seat as it's already paired
                }
            }
        });
        
        const pairCount = pairs.length;
        
        // Add pair information (always show, even if 0 pairs)
        const pairDetails = pairs.map((pair, idx) => {
            return `**[Pair ${idx + 1}]** ${pair.block} - Row ${pair.row} Seats: ${pair.seat1.seatSeat} & ${pair.seat2.seatSeat}`;
        }).join("\n");
        
        pairInfoText = `
        
**🎫 PAIRS:** ${pairCount}  
${pairCount > 0 ? pairDetails : 'No adjacent pairs found'}`;
        
        // No need to show basket details note
    }

    const message =
        `🎟 **TICKET SUCCESS - Added to Basket**  
═════════════════════════════════════════════════
📅 **Time:** ${new Date().toLocaleString('en-GB', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit' 
            })}  
🏟️ **Game:** ${eventName}  
🆔 **Event ID:** ${monitor.eventId}  
🔗 **Event URL:** ${monitor.eventUrl}  
📍 **Area ID:** ${areaId}  
🔢 **Quantity (monitor):** ${monitor.quantity}  
👤 **Account:** ${userEmail}  
📍 **Endpoint:** ${endpointType}  
            
🎫 **TICKETS:**  
${seatInfo}${pairInfoText}
            
🎯 **SUMMARY:**  
✅ **Total Seats:** ${expectedQuantity || products.length}  
💰 **Total Value:** ${totalValue} ${currency}  
            
═════════════════════════════════════════════════`;

    const seatsHttp = seatsCheckHttpStatus != null ? seatsCheckHttpStatus : '?';
    console.log('[CS] Ticket added to basket | Seats check: ' + seatsCheckEndpointLabel + ', HTTP ' + seatsHttp + ', quantity: ' + monitor.quantity + ' | lock/add: OK');
    
    chrome.runtime.sendMessage({
        action: 'notifyWebhooks',
        message,
        payload: dlJson
    }, (response) => {
        if (chrome.runtime.lastError) {
            console.error('[CS] Webhook send error:', chrome.runtime.lastError);
        }
    });

    // Open new tab after sending success notification
    chrome.runtime.sendMessage({
        action: 'openNewTab',
        url: 'https://www.exampleTicketsbasketaddedinthisWindow.com'
    });

// Play 5s sound
// playNotifySound(5000);

// stop monitoring after successful booking to avoid multiple BOOKINGS
// stopMonitoring('successfully added to basket');
    } // End of else block (successful add to basket)
}

function stopMonitoring(reason) {//stop of monitoring will be received from content script signal
    console.log('[CS] stopMonitoring:', reason);
    monitor.running = false;
    if (nextCheckTimeoutId != null) {
        clearTimeout(nextCheckTimeoutId);
        nextCheckTimeoutId = null;
    }
    if (monitor.intervalId) {
        clearInterval(monitor.intervalId);
        monitor.intervalId = null;
    }
}

function getRequestVerificationToken() {
    try {
        const input = document.querySelector('input[name="__RequestVerificationToken"]');
        if (input && input.value) return input.value;
        const meta = document.querySelector('meta[name="requestverificationtoken"]');
        if (meta && meta.content) return meta.content;
        // try cookie parse
        const match = document.cookie.match(/__RequestVerificationToken=([^;]+)/);
        if (match) return decodeURIComponent(match[1]);
    } catch (e) {
        console.warn('[CS] token parse err', e);
    }
    return null;
}

function playNotifySound(ms = 5000) {
    try {
        const src = chrome.runtime.getURL('sounds/notify.mp3');
        const audio = document.createElement('audio');
        audio.src = src;
        audio.autoplay = true;
        audio.volume = 1;
        audio.play().catch(e => console.warn('[CS] audio play failed', e));
        setTimeout(() => {
            audio.pause();
            try {
                audio.remove();
            } catch (e) {
            }
        }, ms);
        console.log('[CS] playing notify sound for', ms, 'ms');
    } catch (e) {
        console.warn('[CS] play sound error', e);
    }
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Helper: wait for event tab to set eventTabReloaded in storage (set by event tab after load + verification token). Timeout 2 min.
const EVENT_TAB_RELOAD_TIMEOUT_MS = 2 * 60 * 1000; // 2 minutes

/** True while people-ahead queue or BG error403 pause should stall seat-side waits. */
function seatsCheckBlockedByQueueOrPauseSync(snapshot) {
    const until = Number(snapshot.error403PauseUntil) || 0;
    return snapshot.inQueueWaiting === true || (until > 0 && Date.now() < until);
}

async function seatsCheckBlockedByQueueOrPause() {
    const st = await chrome.storage.local.get(['inQueueWaiting', 'error403PauseUntil']);
    return seatsCheckBlockedByQueueOrPauseSync(st);
}

/** Like fixed delay() but only counts elapsed time when queue / error403 pause are clear (same idea as reload-flag wait). */
async function delayUnblockedMs(targetUnblockedMs, pollMs = 1000) {
    let unblockedMs = 0;
    while (unblockedMs < targetUnblockedMs) {
        await delay(pollMs);
        if (!(await seatsCheckBlockedByQueueOrPause())) unblockedMs += pollMs;
    }
}

/** After refreshEventTab was skipped (pause): short unblocked backoff instead of 60s wall clock. */
const BACKOFF_UNBLOCKED_MS_AFTER_REFRESH_BLOCKED = 15 * 1000;

async function waitForEventTabReload(timeoutMs = EVENT_TAB_RELOAD_TIMEOUT_MS) {
    console.log('[CS] Waiting for event tab to set eventTabReloaded after load (max ' + (timeoutMs / 1000) + 's)...');
    const startTime = Date.now();
    const checkInterval = 1000; // Check every 1 second

    while (Date.now() - startTime < timeoutMs) {
        const { eventTabReloaded } = await chrome.storage.local.get('eventTabReloaded');
        if (eventTabReloaded === true) {
            console.log('[CS] Event tab reload completed (flag set by event tab).');
            await chrome.storage.local.set({ eventTabReloaded: false });
            return true;
        }
        await new Promise(resolve => setTimeout(resolve, checkInterval));
    }
    console.warn('[CS] Event tab reload timeout after ' + (timeoutMs / 1000) + 's — reload flag not set.');
    return false;
}

/**
 * Wait for eventTabReloaded. Only counts elapsed time while NOT in queue (people ahead) and NOT in BG error403 pause — those stretch the wait.
 */
async function waitForEventTabReloadUnblocked(maxUnblockedMs, pollMs = 1000) {
    let unblockedMs = 0;
    while (unblockedMs < maxUnblockedMs) {
        const { eventTabReloaded, inQueueWaiting, error403PauseUntil } = await chrome.storage.local.get([
            'eventTabReloaded',
            'inQueueWaiting',
            'error403PauseUntil'
        ]);
        if (eventTabReloaded === true) {
            console.log('[CS] Event tab reload completed (flag set by event tab).');
            await chrome.storage.local.set({ eventTabReloaded: false });
            return true;
        }
        const blocked = seatsCheckBlockedByQueueOrPauseSync({ inQueueWaiting, error403PauseUntil });
        await delay(pollMs);
        if (!blocked) unblockedMs += pollMs;
    }
    console.warn(
        '[CS] eventTabReloaded not set within ' +
            maxUnblockedMs / 1000 +
            's of unblocked wait (queue / error403 pause time excluded).'
    );
    return false;
}

/** Send refreshEventTab; false if BG error403 pause blocks it. */
async function refreshEventTabSendOnly() {
    const { error403PauseUntil = 0 } = await chrome.storage.local.get('error403PauseUntil');
    if (error403PauseUntil > 0 && Date.now() < error403PauseUntil) {
        if (!pauseActiveLogged) {
            console.log('[CS] error403 pause is active — seat checks and event tab refresh paused until it ends.');
            pauseActiveLogged = true;
        }
        return false;
    }
    await chrome.storage.local.set({ eventTabReloaded: false });
    console.log('[CS] Sending refresh event tab message (event tab will set eventTabReloaded when loaded with verification token).');
    chrome.runtime.sendMessage({ action: 'refreshEventTab' }, (response) => {
        if (chrome.runtime.lastError) {
            console.error('[CS] refreshEventTab error:', chrome.runtime.lastError);
        } else {
            console.log('[CS] refreshEventTab response:', response);
        }
    });
    return true;
}

/** 3× seats 403: send refresh, wait 60s unblocked for flag; if none, send again + wait again. Retries send while BG pause blocks (up to ~15m). */
async function handleThreeConsecutiveSeat403Refresh() {
    const unblockWaitMs = 60 * 1000;
    const pauseRetryWallMs = 15 * 60 * 1000;
    const stepMs = 2000;

    const sendWhenPauseClears = async () => {
        const deadline = Date.now() + pauseRetryWallMs;
        while (Date.now() < deadline) {
            if (await refreshEventTabSendOnly()) return true;
            await delay(stepMs);
        }
        console.warn('[CS] 3×403: could not send refresh — error403 pause did not clear within ~15m.');
        return false;
    };

    if (!(await sendWhenPauseClears())) return;

    let ok = await waitForEventTabReloadUnblocked(unblockWaitMs);
    if (ok) return;

    console.warn('[CS] 3×403: no reload flag after first unblocked 60s — sending second refreshEventTab.');
    if (!(await sendWhenPauseClears())) return;
    ok = await waitForEventTabReloadUnblocked(unblockWaitMs);
    if (!ok) {
        console.warn('[CS] 3×403: still no reload flag after second unblocked 60s.');
        lastEventTabRefreshAt = Date.now();
    }
}

/**
 * Refresh event tab and wait for eventTabReloaded. On first wait timeout, sends a second refresh and waits again.
 * Returns true only when reload flag is seen. Returns false if pause blocked send, or both waits timed out (seat API should not run).
 */
async function refreshEventTabWithTracking() {
    const sent = await refreshEventTabSendOnly();
    if (!sent) {
        return false;
    }
    let completed = await waitForEventTabReload(EVENT_TAB_RELOAD_TIMEOUT_MS);
    if (!completed) {
        console.warn('[CS] Event tab reload timeout — sending second refreshEventTab and waiting again (max ' + EVENT_TAB_RELOAD_TIMEOUT_MS / 1000 + 's)...');
        const sent2 = await refreshEventTabSendOnly();
        if (!sent2) {
            lastEventTabRefreshAt = Date.now();
            pendingSkipSeatFetchEventReloadTimeout = true;
            return false;
        }
        completed = await waitForEventTabReload(EVENT_TAB_RELOAD_TIMEOUT_MS);
    }
    if (!completed) {
        console.warn('[CS] Event tab reload still not confirmed after second wait — will skip seat API until reload succeeds.');
        lastEventTabRefreshAt = Date.now();
        pendingSkipSeatFetchEventReloadTimeout = true;
        return false;
    }
    pendingSkipSeatFetchEventReloadTimeout = false;
    return true;
}
